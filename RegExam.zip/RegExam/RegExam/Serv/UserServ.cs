﻿using System.Linq;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using System.Collections.Generic;
using RegExam.Data;

namespace RegExam.Serv
{
    public class UserServ
    {
        public void InsertUser(User user)
        {
            MongoClient client = new MongoClient("mongodb://localhost:27017");
            var connection = client.GetDatabase("ExamGin");
            var collection = connection.GetCollection<User>("Users");
            collection.InsertOne(user);
        }
    }
}
